function show(index){
all_cards = document.getElementsByClassName("accordion");
for(i=0 ;i< all_cards.length;i++){
    all_cards[i].classList.add("hidden");
}
all_cards[index].classList.remove("hidden");
}

// let active = document.querySelectorAll(".accordion-div .accordion.active");
//   for(let j = 0; j < active.length; j++){
//     active[j].classList.remove("active");
//     active[j].nextElementSibling.style.maxHeight = null; //or 0px
//   }